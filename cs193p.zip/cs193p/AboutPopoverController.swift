//
//  AboutPopoverController.swift
//  cs193p
//
//  Created by Mr.Q.Young on 16/7/16.
//  Copyright © 2016年 Yorn. All rights reserved.
//

import UIKit

class AboutPopoverController: UIPopoverController {
    

}
