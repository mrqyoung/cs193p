//
//  CalcModul.swift
//  Calc
//
//  Created by Mr.Q.Young on 16/7/12.
//  Copyright © 2016年 Yorn. All rights reserved.
//

import Foundation



class CalculatorNormalModel: CalculatorModel {
    
    var title: String = "Infix Expression Calculator"
    
    func pushOperand(operand o: Double) {
    }
    
    func performOperation(operation o: String) -> Double? {
        return nil
    }
    
    func reset() {
    }
}
